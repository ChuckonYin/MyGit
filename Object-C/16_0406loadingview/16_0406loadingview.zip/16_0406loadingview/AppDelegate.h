//
//  AppDelegate.h
//  16_0406loadingview
//
//  Created by ChuckonYin on 16/4/6.
//  Copyright © 2016年 PingAn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

