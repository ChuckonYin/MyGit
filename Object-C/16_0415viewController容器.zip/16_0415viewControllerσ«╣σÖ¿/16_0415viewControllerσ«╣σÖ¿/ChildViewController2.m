//
//  ChildViewController2.m
//  16_0415viewController容器
//
//  Created by ChuckonYin on 16/4/15.
//  Copyright © 2016年 pinAn.com. All rights reserved.
//

#import "ChildViewController2.h"

@interface ChildViewController2 ()

@end

@implementation ChildViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.view.backgroundColor = [UIColor yellowColor];
    
}
@end
