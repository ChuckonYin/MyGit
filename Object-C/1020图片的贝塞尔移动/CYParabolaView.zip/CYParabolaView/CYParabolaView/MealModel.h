//
//  MealModel.h
//  CYParabolaView
//
//  Created by ChuckonYin on 15/10/24.
//  Copyright © 2015年 PingAn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MealModel : NSObject


@property (nonatomic, copy) NSString *name;

@end
