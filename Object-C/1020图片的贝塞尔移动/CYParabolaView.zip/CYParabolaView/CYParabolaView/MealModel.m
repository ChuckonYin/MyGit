//
//  MealModel.m
//  CYParabolaView
//
//  Created by ChuckonYin on 15/10/24.
//  Copyright © 2015年 PingAn. All rights reserved.
//

#import "MealModel.h"

@implementation MealModel

@end
