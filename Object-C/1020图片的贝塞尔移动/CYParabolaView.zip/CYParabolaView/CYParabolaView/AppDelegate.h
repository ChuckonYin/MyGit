//
//  AppDelegate.h
//  CYParabolaView
//
//  Created by ChuckonYin on 15/10/19.
//  Copyright © 2015年 PingAn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

