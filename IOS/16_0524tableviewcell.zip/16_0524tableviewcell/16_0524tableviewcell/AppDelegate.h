//
//  AppDelegate.h
//  16_0524tableviewcell
//
//  Created by ChuckonYin on 16/5/24.
//  Copyright © 2016年 pinAn.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

